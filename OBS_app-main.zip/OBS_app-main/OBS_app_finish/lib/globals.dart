// globals.dart
library globals;

// Giriş yapan kullanıcının adı ve e-posta bilgileri burada tutulacak
String globalName = '';
String globalEmail = '';
