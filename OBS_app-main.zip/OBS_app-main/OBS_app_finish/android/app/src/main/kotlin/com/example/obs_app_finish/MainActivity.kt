package com.example.obs_app_finish

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
